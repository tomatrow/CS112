public interface Controller {
	public void onVisible(MainFrame frame);
}
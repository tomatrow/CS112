public interface ImageScrollPanelDelegate {
	public void imageAtIndexClicked(int index);
}
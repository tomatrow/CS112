public interface SubredditControlsDelegate {
	public void buttonClickedWithText(String text);
}
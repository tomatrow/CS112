# LushDown
A markdown editor written at Lush Coffee and Tea in Vista. 

## Features 
* Upload to PasteBin
* Raw HTML and marked up preview